This is a FAT test image for Daylight savings time.  There are two
files on the image.  The 'winter.txt' file was created at 2:00PM
on January 1, 2004.  The 'summer.txt' file was created at 3:00PM
on June 1, 2004.  The contents of each file contain the creation
time.

The files were created on a Windows XP system by setting the date
and then creating the file.


brian carrier
carrier@cerias.purdue.edu
Jan 29, 2004


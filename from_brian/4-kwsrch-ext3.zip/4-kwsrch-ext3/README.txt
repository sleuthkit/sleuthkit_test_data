
                   Test 4 - EXT3 Keyword Search Image #1
                               November 2003

                              http://dftt.sf.net
                                 Brian Carrier
                           carrier@cerias.purdue.edu

---------------------------------------------------------------------------
This is a test image for testing digital forensic analysis tools.
Import it into the tool of your choice (it is an EXT3FS file system
image in a raw format) and search for the terms identified in the
'index.html' file.

This image is released under the terms of the GNU General Public
License as published by the Free Software Foundation.  It is included
in the COPYING file.

This work is not sponsored by Purdue University or CERIAS.


                       Test 10 - NTFS Autodetect Image
                                 Jan 2005

                            http://dftt.sf.net
                               Brian Carrier

---------------------------------------------------------------------------
These are test images for testing digital forensic analysis tools.
Import them into the tool of your choice and determine which files
are shown.  The contents of each image can be found in index.html.

This image is released under the terms of the GNU General Public
License as published by the Free Software Foundation.  It is included
in the COPYING file.

Brian Carrier
carrier@cerias.purdue.edu
This work is not sponsored by Purdue University or CERIAS.
